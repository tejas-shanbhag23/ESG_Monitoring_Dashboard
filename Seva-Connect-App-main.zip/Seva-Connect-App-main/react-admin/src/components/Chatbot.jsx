import React from "react";

const Chatbot = () => {
  return (
    <div>
      <iframe
        src="https://www.chatbase.co/chatbot-iframe/hRcvraiM1WAVUf3PYgmkq"
        title="Chatbot"
        width="100%"
        style={{height:100,minHeight:700}}
        frameborder="0"
      ></iframe>
    </div>
  );
};

export default Chatbot;
