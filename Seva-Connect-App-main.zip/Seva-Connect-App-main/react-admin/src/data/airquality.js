
export const airquality=[
  {
    "collegeCampus": {
      "campusName": "Sample University",
      "location": "Citytown, State",
      "totalTreeCanopyArea": {
        "value": 130000,  // in square meters
        "unit": "m²"
      },
      "totalLandArea": {
        "value": 500000,  // in square meters
        "unit": "m²"
      }
    }
  }  
]